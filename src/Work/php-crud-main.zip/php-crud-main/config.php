<?php

$con = mysqli_connect("localhost","root","","nasir") or die("connection failed");



?>